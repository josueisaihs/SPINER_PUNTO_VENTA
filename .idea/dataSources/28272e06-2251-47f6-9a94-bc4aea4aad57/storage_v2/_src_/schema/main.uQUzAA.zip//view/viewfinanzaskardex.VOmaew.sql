CREATE VIEW ViewFinanzasKardex AS 
  SELECT EventsLog.time, Invoices.type, Classify.supplier, sum(ClassifyKardex.newCant),
  sum(Classify.costProd * ClassifyKardex.newCant), Kardex.tax, '0.0', Kardex.total, -Kardex.total FROM EventsLog, Invoices, Classify, ClassifyKardex, Kardex
  WHERE Kardex.id_invoice == ClassifyKardex.id_invoice AND Kardex.id_invoice == Invoices.id
  AND Invoices.id_event == EventsLog.id_event
  AND ClassifyKardex.id_classify == Classify.id GROUP BY Invoices.id ORDER BY EventsLog.time DESC;

