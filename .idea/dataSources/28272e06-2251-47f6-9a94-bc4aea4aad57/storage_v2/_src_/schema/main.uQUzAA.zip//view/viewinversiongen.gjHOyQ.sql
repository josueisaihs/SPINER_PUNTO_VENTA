CREATE VIEW ViewInversionGen AS
  SELECT count(DISTINCT C.codeCom), sum(abs(C.cantAlm)), count(DISTINCT C.supplier), sum(C.costProd * abs(C.cantAlm)),
    sum(max(C.price1, C.price2, C.price3, C.price4) * abs(C.cantAlm)) - sum(C.costProd * abs(C.cantAlm)),
    sum(min(C.price1, C.price2, C.price3, C.price4) * abs(C.cantAlm)) - sum(C.costProd * abs(C.cantAlm)),
    sum(C.flete * abs(C.cantAlm)), sum(max(C.price1, C.price2, C.price3, C.price4) * abs(C.cantAlm))
  FROM Classify C;

