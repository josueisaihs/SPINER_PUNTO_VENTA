CREATE TRIGGER eventsLog AFTER INSERT ON Events
  BEGIN
  INSERT INTO EventsLog(id_event, time) VALUES (new.ID, datetime('now', 'localtime'));
END;

