CREATE VIEW ViewInversion AS
  SELECT Co.component, C.codeCom, C.codeFab, C.cantAlm, C.costProd, abs(C.cantAlm) * C.costProd, C.price1, C.price2,
    C.price3, C.price4, abs(C.cantAlm) * C.price1, abs(C.cantAlm) * C.price2, abs(C.cantAlm) * C.price3,
    abs(C.cantAlm) * C.price4, max(C.price1, C.price2, C.price3, C.price4) * abs(C.cantAlm),
    min(C.price1, C.price2, C.price3, C.price4) * abs(C.cantAlm), C.flete, abs(C.cantAlm) * C.flete
  FROM Classify C, Components Co
  WHERE C.id_component == Co.id AND abs(C.cantAlm) > 0
  GROUP BY C.codeCom ORDER BY C.cantVisit;

