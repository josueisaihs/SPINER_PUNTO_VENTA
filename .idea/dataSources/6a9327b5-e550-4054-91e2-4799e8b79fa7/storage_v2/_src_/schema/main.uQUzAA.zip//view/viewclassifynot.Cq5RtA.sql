CREATE VIEW ViewClassifyNot AS 
  SELECT codeCom, codeFab FROM Classify WHERE (cantAlm < (SELECT cant FROM ClassifySales WHERE
  (Classify.id == ClassifySales.id_classify) AND (SELECT EventsLog.time FROM EventsLog, Events, Invoices WHERE
  EventsLog.id_event == Invoices.id_event AND Invoices.id == ClassifySales.id_invoice) >
  (SELECT (julianday('now') - 2440587.5) * 86400.0 - 30 * 24 * 60 * 60)) OR (Classify.cantAlm <
   Classify.cantMin * (1 + (cantVisit * 100 / (SELECT sum(cantVisit) FROM Classify) * 0.5 - 0.1))))
  LIMIT 20;

