CREATE VIEW ViewReorden AS
  SELECT C.id, Co.component, C.codeCom, C.codeFab, C.supplier, C.costProd, C.cantAlm, C.cantMin, C.flete, C.detail
  FROM Classify C, Components Co WHERE (C.cantAlm <= C.cantMin OR C.cantAlm <= 0) AND Co.id == C.id_component
  ORDER BY C.cantVisit DESC;

