CREATE VIEW ViewClassifyKardex AS
  SELECT EL.time, I.type, C.codeCom, C.codeFab, C.supplier, C.cantAlm, CK.newCant, C.costProd, CK.newCant * C.costProd
  FROM ClassifyKardex CK, Classify C, EventsLog EL, Invoices I WHERE
    CK.id_invoice == I.id AND CK.id_classify == C.id AND I.id_event == EL.id_event AND I.type GLOB 'KI-*'
  ORDER BY EL.time DESC;

