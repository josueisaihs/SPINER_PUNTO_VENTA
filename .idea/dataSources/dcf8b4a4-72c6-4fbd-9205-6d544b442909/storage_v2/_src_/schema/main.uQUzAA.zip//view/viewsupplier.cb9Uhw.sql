CREATE VIEW ViewSupplier AS
  SELECT DISTINCT supplier, count(DISTINCT codeCom), sum(cantAlm) FROM Classify GROUP BY supplier ORDER BY count(DISTINCT codeCom) DESC;

