CREATE VIEW ViewFinanzasVentas AS
  SELECT EventsLog.time, Invoices.type, Clients.client, sum(ClassifySales.cant),
  sum(Classify.costProd * ClassifySales.cant), Sales.discount, Sales.total, sum(Classify.costProd * ClassifySales.cant),
  Sales.total - sum(Classify.costProd * ClassifySales.cant) FROM EventsLog, Invoices, Clients, ClassifySales, Sales,
  Classify WHERE EventsLog.id_event == Invoices.id_event AND Invoices.id == Sales.id_invoice AND
                 ClassifySales.id_invoice == Sales.id_invoice
  AND ClassifySales.id_classify == Classify.id AND Sales.id_client == Clients.id GROUP BY Invoices.id
  ORDER BY EventsLog.time DESC;

