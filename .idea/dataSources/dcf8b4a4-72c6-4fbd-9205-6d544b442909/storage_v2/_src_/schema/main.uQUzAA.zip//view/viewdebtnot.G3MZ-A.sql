CREATE VIEW ViewDebtNot AS
  SELECT Debt.id_client, sum(Debt.money - Debt.dep) FROM Debt WHERE Debt.money - Debt.dep > 0
  GROUP BY Debt.id_client ORDER BY Debt.money - Debt.dep DESC;

